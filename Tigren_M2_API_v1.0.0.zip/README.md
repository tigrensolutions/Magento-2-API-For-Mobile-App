## Homepage

https://www.tigren.com/

## Github

https://github.com/tigrensolutions/magento-integration-suite

## Installation

In your Magento2 root directory, you may install this package via composer:

`composer require tigrensolutions/magento-integration-suite`

`php bin/magento setup:upgrade`